<template>
  <div class="p-10">
    <h1 class="text-2xl font-bold">Привет! Всё собрано, Inertia+Vue работают </h1>
  </div>
</template>

<script setup>
</script>
