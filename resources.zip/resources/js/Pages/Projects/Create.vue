<template>
  <div>Страница создания проекта работает!</div>
</template>

<script setup>
</script>
