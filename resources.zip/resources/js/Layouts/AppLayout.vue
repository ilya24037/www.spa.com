<template>
  <div class="min-h-screen bg-gray-100 flex flex-col"> <!-- Изменил на gray-100 -->
    <div class="max-w-[1400px] mx-auto bg-white min-h-screen">
      
      <!-- MainHeader с фиксированной высотой 64px -->
      <header class="sticky top-0 z-50 bg-white shadow-md rounded-b-2xl h-16"> <!-- Добавил h-16 (64px) -->
        <ErrorBoundary 
          error-title="Навигация временно недоступна"
          :show-reload="false"
        >
          <Navbar />
        </ErrorBoundary>
      </header>
      
      <!-- Основной контент с site-wrapper -->
      <main class="site-wrapper"> <!-- Изменил на site-wrapper -->
        <slot />
      </main>
      
      <!-- Футер -->
      <footer class="bg-white rounded-t-2xl mt-8 py-4 text-center text-sm text-gray-500">
        © {{ new Date().getFullYear() }} SPA Platform
      </footer>
    </div>
    
    <!-- Уведомления вне контейнера -->
    <ToastNotifications />
  </div>
</template>

<script setup>
import Navbar from '@/Components/Header/Navbar.vue'
import ErrorBoundary from '@/Components/Common/ErrorBoundary.vue'
import ToastNotifications from '@/Components/Common/ToastNotifications.vue'
</script>

<style scoped>
/* Отступы по бокам через .site-wrapper как в документе */
.site-wrapper {
  @apply pt-4 px-4;
}
</style>