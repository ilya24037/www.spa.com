<!-- resources/js/Components/Header/Logo.vue -->
<template>
  <Link href="/" class="text-2xl font-bold text-blue-600 hover:text-blue-700 transition">
    MASSAGIST
  </Link>
</template>

<script setup>
import { Link } from '@inertiajs/vue3'
</script>